<html>

<head>

    <head>
        <!--- basic page needs
    ================================================== -->
        <meta charset="utf-8">
        <title>Electrical Engineering Competition | Technocorner 2021</title>
        <meta name="description" content="TECHNOCORNER UGM 2021">
        <meta name="author" content="DIVISI SOFTWEB Technocorner 2021">
        <meta name="keywords" content="TC TECHNOCORNER DTETI UGM TECHNOLOGY 2021">

        <!-- mobile specific metas
    ================================================== -->
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSS
    ================================================== -->
        <link rel="stylesheet" href="<?= base_url('/frontend'); ?>/css/base.css">
        <link rel="stylesheet" href="<?= base_url('/frontend'); ?>/css/vendor.css">
        <link rel="stylesheet" href="<?= base_url('/frontend'); ?>/css/main.css">
        <link rel="stylesheet" href="<?= base_url('/frontend'); ?>/css/styles.css">
        <link rel="stylesheet" href="<?= base_url('/frontend'); ?>/landing/libraries/fontawesome/css/all.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

        <!-- script
    ================================================== -->
        <script src="<?= base_url('/frontend'); ?>/js/modernizr.js"></script>
        <script src="<?= base_url('/frontend'); ?>/js/pace.min.js"></script>

        <!-- favicons
    ================================================== -->
        <link rel="shortcut icon" href="<?= base_url('/frontend'); ?>/favicon.ico" type="image/x-icon">
        <link rel="icon" href="<?= base_url('/frontend'); ?>/favicon.ico" type="image/x-icon">

        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">
        <link href="<?= base_url('/frontend'); ?>/css/bootstrap/bootstrap-grid.min.css">

    </head>

<body class="competition">
    <header>

        <nav class="navbar opaque fixed-top navbar-expand-lg  " style="padding: 0 30px">

            <a class="navbar-brand " href="<?= base_url(); ?>"><img style="max-width:50px; height: auto;" src="<?= base_url('/frontend'); ?>/images/LOGO.png" alt="" title=""> TECHNOCORNER</a>
            <button class="navbar-toggler navbar-dark" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class=" ml-auto navbar-nav" style="font-weight: bold">
                    <li class="nav-item ">
                        <a class="nav-link" target="_blank" href="<?= base_url(); ?>">Home</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" target="_blank" href="<?= base_url('/page/gallery'); ?>">Gallery</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Events
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" target="_blank" href="<?= base_url('/page/competition'); ?>/transporter/">TransporterBot</a>
                            <a class="dropdown-item" target="_blank" href="<?= base_url('/page/competition'); ?>/linefollower/">Line Follower</a>
                            <a class="dropdown-item" target="_blank" href="<?= base_url('/page/competition'); ?>/iot/">IoT Development</a>
                            <a class="dropdown-item" target="_blank" href="<?= base_url('/page/competition'); ?>/eec/">EEC</a>
                            <a class="dropdown-item" target="_blank" href="<?= base_url('/page'); ?>/webinar/">Webinar</a>
                            <a class="dropdown-item" target="_blank" href="<?= base_url('/page'); ?>/workshop/">Workshop</a>
                        </div>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" target="blank" href="<?= base_url('/auth'); ?>">Login</a>
                    </li>
                    <!-- <li class="nav-item ">
              <a class="nav-link" target="_blank" href="#">Seminar</a>
            </li> -->
                    <!-- <li class="nav-item " >
              <a class="nav-link" target="_blank" style="border: 2px white solid; border-radius: 10px;" href="technocornerugm.com/akun/">Login</a>
            </li> -->
                </ul>
            </div>
        </nav>


    </header>
    <!-- end s-header -->

    <div id="eec">
        <div class="container lomba">
            <h1 style=" border-bottom: 2px solid rgba(255, 255, 255, 0.893);" class="display-2 text-center mb-5 " data-aos="zoom-in" data-aos-duration="700">Event</h1>

            <div class="tc-overlay"></div>

            <div class="row">
                <div class="desc bg-gradation-purple-2" data-aos="fade-up" data-aos-duration="700">
                    <div class="col-sm-12">
                        <h1 class="glow text-center">Electrical Engineering<br> Competition</h1>
                    </div>
                    <div class="px-5">
                        <div class="col-sm-12 col-md-6 text-center" style="margin-top: 30px ;">
                            <img class="revert-x responsive-img" src="<?= base_url('/frontend'); ?>/images/Logo/logo-eec.png" alt="" title="">
                        </div>
                        <div class="col-sm-12 col-md-6 " style="margin-top: 30px;">
                            <h5><br> EEC merupakan sebuah kompetisi di bidang matematika, fisika, dan komputer. Format kompetisi ini beregu, dimana tiap regu/tim terdiri dari 3 orang siswa SMA/sederajat se-Indonesia. Kompetisi ini dilaksanakan dalam 3
                                babak, yaitu penyisihan, semifinal, dan final. penyisihan dilaksanakan secara daring dalam waktu yang bersamaan. 15 tim terbaik akan melaju ke babak semifinal yang diselenggarakan secara daring.
                            </h5>
                        </div>
                    </div>
                </div>
            </div>


            <div class="pt-5">


                <div class="row detail">
                    <h2 class="title col-sm-12" style="margin-bottom: 30px">Kategori</h2>
                    <div class="col-sm-12 col-md-3  text-center logo-fa ">
                        <img src="<?= base_url('/frontend'); ?>/images/Logo/Icon Web TC-Kategori-01.png">
                        <!--<h1><i class="fa fa-users" aria-hidden="true"></i></h1>-->
                    </div>
                    <div class="col-sm-12 col-md-9 my-auto">
                        <h3>Terbuka untuk pelajar SMA/sederajat</h3>
                        <h5>Tim terdiri dari 3 orang</h5>
                    </div>
                </div>

                <div class="row detail">
                    <h2 class="title col-sm-12" style="margin-bottom: 30px">Agenda</h2>
                    <div class="col-sm-12 col-md-3 text-center logo-fa ">
                        <img src="<?= base_url('/frontend'); ?>/images/Logo/Icon Web TC-Agenda-01.png">
                        <!--<h1><i class="fa fa-calendar-o" aria-hidden="true"></i></h1>-->
                    </div>
                    <div class="col-sm-12 col-md-9 my-auto">
                        <h3>Pendaftaran Online</h3>
                        <h5>14 Maret 2021 - 17 April 2021</h5><br>
                        <h3>Babak Penyisihan Online</h3>
                        <h5>8 Mei 2021</h5><br>
                        <h3>Babak Semifinal</h3>
                        <h5>29 Mei 2021</h5><br>
                        <h3>Babak Grand Final</h3>
                        <h5>30 Mei 2021</h5>
                    </div>
                </div>

                <div class="row detail">
                    <h2 class="title col-sm-12" style="margin-bottom: 30px">Kontak</h2>
                    <div class="col-sm-12 col-md-3 text-center logo-fa ">
                        <img src="<?= base_url('/frontend'); ?>/images/Logo/Icon Web TC-Kontak-01.png">
                        <!--<h1><i class="fa fa-phone" aria-hidden="true"></i></h1>-->
                    </div>
                    <div class="col-sm-12 col-md-9 my-auto">
                        <h3>Raihan Rahmanda</h3>
                        <h4>
                            Whatsapp: <a href="#">085156570260</a><br> LINE: <a href="#">raihan_rah</a>
                        </h4><br>
                        <h3>Lingga Ara Hiwang</h3>
                        <h4>
                            Whatsapp: <a href="#">081225092501</a><br> LINE: <a href="#">linggaara01</a>
                        </h4>
                    </div>
                </div>

                <div class="row detail">
                    <h2 class="title col-sm-12" style="margin-bottom: 30px">Total Hadiah</h2>
                    <div class="col-sm-12 col-md-3 text-center logo-fa ">
                        <img src="<?= base_url('/frontend'); ?>/images/Logo/Icon Web TC-Total Hadiah-01.png">
                        <!--<h1><i class="fa fa-gift" aria-hidden="true"></i></h1>-->
                    </div>
                    <div class="col-sm-12 col-md-9 my-auto">
                        <h2>Rp 6.000.000</h2>
                    </div>
                </div>

                <div class="row detail">
                    <h2 class="title col-sm-12" style="margin-bottom: 30px">Petunjuk Lomba</h2>
                    <div class="col-sm-12 col-md-3 text-center logo-fa ">
                        <img src="<?= base_url('/frontend'); ?>/images/Logo/Icon Web TC-Petunjuk Lomba-01.png">
                        <!--<h1><i class="fa fa-file-text-o" aria-hidden="true"></i></h1>-->
                    </div>
                    <div class="col-sm-12 col-md-9 my-auto">
                        <a target="_blank" href="https://drive.google.com/file/d/1R57tYeDp73q9kOE7RfPT3tiqjwbaMpvx/view?usp=sharing"> <button class="btn-ref">Petunjuk Umum</button></a>
                        <a target="_blank" href="https://drive.google.com/file/d/1mkr9wwP4VhNgvarrF4ERWE3vCH-1Bxmz/view?usp=sharing"> <button class="btn-ref">Petunjuk Teknis</button></a>
                    </div>
                </div>

            </div>


        </div>
        <!--end of container-->

        <!-- clients
    ================================================== -->
        <div id="clients" class="s-clients ">

            <div class="row-gl-tc section-header-gl-tc has-bottom-sep" data-aos="fade-up" data-aos-duration="400">
                <div class="col-full">
                    <!-- <h3 class="subhead">Our Clients</h3> -->
                    <h1 class="display-2">partnership</h1>
                </div>
            </div>
            <!-- end section-header-gl-tc -->

            <div id="partner" class="row-gl-tc" data-aos="fade-up" data-aos-duration="400">
                <div class="col-full">
                    <h3 style="color: #555555;">sponsor: </h3>
                </div>
                <div class="col-full line">

                </div>

                <div class="col-full">
                    <h3 style="color: #555555;">media partner: </h3>
                </div>
                <div id="medpart" class="col-full">

                </div>
            </div>

            <div class="text-center" style="margin-top: 50px; margin-bottom: -50px; padding: 0 3rem;" data-aos="fade-up" data-aos-duration="400">
                <h3>
                    interested to be our partnership?
                </h3>
                <button class="btn-ref mt-4">contact us:</button>
                <div class="row-gl-tc text-left cp block-1-2 block-tab-full" style="margin-top: 30px;">
                    <div class="col-block line-2" style="height: 130px;">
                        <h3 class="text-center mb-0">sponsorship:</h3>
                        <h4 class="text-center mb-4" style="color: #555555"><u>Aulia Rahmatsani M.</u></h4>
                        <a target="_blank" href="https://api.whatsapp.com/send?phone=6285869104108&text=Halo%2C%20saya%20mau%20bertanya%20tentang%20sponsorship%20Technocorner%202020%0A"><i class="fa fa-whatsapp" aria-hidden="true" style="margin-right: 12px"></i> 085869104108</a><br>
                        <a href="#"><i class="fa fa-envelope" aria-hidden="true" style="margin-right: 10px"></i>
                            auliarahmatsani@mail.ugm.ac.id</a>
                    </div>
                    <div class="col-block" style="height: 130px;">
                        <h3 class="text-center mb-0">media partner:</h3>
                        <h4 class="text-center mb-4" style="color: #555555"><u>Pandhu Ardi Prasetyo</u></h4>
                        <a href="https://api.whatsapp.com/send?phone=6281227023681&text=Halo%2C%20saya%20mau%20bertanya%20tentang%20media%20partner%20Technocorner%202020%0A" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true" style="margin-right: 12px"></i> 081227023681</a><br>
                        <a href="#"><i class="fa fa-envelope" aria-hidden="true" style="margin-right: 10px"></i>
                            pandhuardi00@mail.ugm.ac.id</a>
                    </div>
                </div>
            </div>

        </div>
        <!-- end s-clients -->

        <!-- footer
    ================================================== -->
        <footer style="background: #111111;">

            <div class="row-gl-tc footer-main">

                <div class="col-six tab-full left footer-desc">

                    <h1 class="my-4">Technocorner 2021</h1>
                    <h3>Competition Held On:</h3>
                    <div class="mapouter">
                        <div class="gmap_canvas">
                            <iframe width="300" height="300" id="gmap_canvas" src="https://maps.google.com/maps?q=sleman%20city%20hall&t=k&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                        </div>
                        <!-- <style>
                        .mapouter {
                            position: relative;
                            text-align: right;
                            height: 300px;
                            width: 300px;
                        }

                        .gmap_canvas {
                            overflow: hidden;
                            background: none !important;
                            height: 300px;
                            width: 300px;
                        }
                    </style> -->
                    </div>

                </div>

                <div class="col-six  tab-full right footer-subscribe">

                    <h4 class="display-2" style="font-size: 4vh;">Get Notified!</h4>
                    <ul class="header-nav__social">
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="https://www.facebook.com/TechnocornerUGM/" target="_blank"><i class="fab fa-facebook" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="https://twitter.com/technocornerugm?lang=en" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="https://www.linkedin.com/company/technocorner-ugm-2021/" target="_blank"><i class="fab fa-linkedin" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="https://www.tiktok.com/@technocornerugm" target="_blank"><i class="fab fa-tiktok" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="https://www.youtube.com/channel/UC0T3ca79_Db-q9sHXTYeXIg" target="_blank"><i class="fab fa-youtube" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="https://instagram.com/technocornerugm/" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                        <li style="margin-right: 3vh;">
                            <h1 style="font-size: 8vh;">
                                <a href="http://line.me/ti/p/@kdo2899c" target="_blank"><i class="fab fa-line" aria-hidden="true"></i></a>
                            </h1>
                        </li>
                    </ul>

                </div>

            </div>
            <!-- end footer-main -->

            <div class="row-gl-tc footer-bottom" style="border-top: 1px solid white;">

                <div class="col-twelve">
                    <div class="copyright" style="color: #fff; margin-top: 10px">
                        <span>©Divisi Softweb Technocorner 2021</span>
                    </div>

                    <div class="go-top">
                        <a class="smoothscroll" title="Back to Top" href="#eec"><i class="icon-arrow-up" aria-hidden="true"></i></a>
                    </div>
                </div>

            </div>
            <!-- end footer-bottom -->

        </footer>
        <!-- end footer -->

    </div>
    <!-- end of div -->

    <!-- Java Script
    ================================================== -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script src="<?= base_url('/frontend'); ?>/js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url('/frontend'); ?>/js/plugins.js"></script>
    <script src="<?= base_url('/frontend'); ?>/js/main.js"></script>
</body>

</html>