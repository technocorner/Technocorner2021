<?= $this->extend('dashboard/template/dashboard_template'); ?>
<?= $this->section('content'); ?>
<?= $this->include('dashboard/template/nav'); ?>
<?= $this->include('dashboard/template/sidebar'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-12">
                    <h1 class="m-0">Webinar Nasional</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="col-md-12">
                    <div class="card card-default">
                        <div class="card-footer">
                            <a class="btn btn-block bg-gradient-primary btn-lg disable" href="LINK GFORM NUNGGU KSK">Pendaftaran belum dibuka</a>
                        </div>
                        <!-- /.card-footer-->
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card card-default">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg-8 col-12 order-md-1 order-2">
                                    <!-- Default box -->
                                    <div class="card justify-content-center align-items-center">
                                        <div class="card-body justify-content-center align-items-center">
                                            <p>
                                                Technocorner 2021 mengadakan sebuah webinar nasional dengan tema
                                                <b>"<i>Innovative Technology to Prepare The Post-Pandemic Society</i>"</b>.
                                                Sosialisasi adalah suksesor bagi sebuah teknologi. Oleh karena itu, dibutuhkan Webinar Nasional
                                                untuk memahamkan dan mengenakan kepada ahli dan masyarakat luas mengenai evolusi dalam bidang teknologi
                                                dalam mempersiapkan masa setelah pandemi. Webinar Nasional ini bertujuan untuk mengenalkan akan pentingnya
                                                strategi teknologi di masa pandemi dan setelah pandemi, demi mewujudkan efektivitas teknologi yang lebih maju.
                                                Dengan strategi teknologi yang baik, kehidupan setelah pandemi akan menjadi lebih mudah.
                                            </p>
                                        </div>
                                        <!-- /.card-body -->
                                    </div>
                                    <!-- /.card -->
                                </div>

                                <div class="col-lg-4 col-12 order-md-2 order-1">
                                    <!-- Default box -->
                                    <div class="justify-content-center align-items-center d-flex">
                                        <div class="image">
                                            <img src="<?= base_url('/frontend/images/logo/logo-semnas.png'); ?>" class="events-img" alt="User Image">
                                        </div>
                                    </div>
                                    <!-- /.card -->
                                </div>
                                <!-- /.col-4 -->
                            </div>
                            <!-- /.row -->
                        </div>
                        <!-- ./card-body -->
                    </div>
                    <!-- /.col-md-12 -->
                </div>
                <!-- /.card-body -->


            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
<?= $this->endSection(); ?>