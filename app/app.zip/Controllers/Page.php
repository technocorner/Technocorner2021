<?php

namespace App\Controllers;

use App\Models\AccessModel;
use App\Models\TeamModel;
use App\Models\UserModel;

class Page extends BaseController
{

    public function index()
    {
        return view('landing/home');
    }

    public function transporter()
    {
        return view('landing/competition/transporter');
    }

    public function linefollower()
    {
        return view('landing/competition/line');
    }

    public function iot()
    {
        return view('landing/competition/iot');
    }

    public function eec()
    {
        return view('landing/competition/eec');
    }

    public function gallery()
    {
        return view('landing/gallery');
    }


    public function webinar()
    {
        return view('landing/competition/webinar');
    }

    public function workshop()
    {
        return view('landing/competition/workshop');
    }

    //--------------------------------------------------------------------

}
