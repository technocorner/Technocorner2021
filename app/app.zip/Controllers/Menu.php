<?php

namespace App\Controllers;

use App\Models\AccessModel;
use App\Models\UserModel;
use App\Models\AdminModel;
use App\Models\LombaModel;
use App\Models\TeamModel;
use CodeIgniter\API\ResponseTrait;

class Menu extends BaseController
{
    use ResponseTrait;

    public function test()
    {
        return view('email/pembayaran');
    }
    public function dashboard()
    {

        $accessModel = new AccessModel();
        $userModel = new UserModel();
        $teamModel = new TeamModel();
        $data = [
            'css' => array(base_url('assets/css/main-dashboard.css')),
            'tes' => 'admin',
            'pemberitahuan' => $userModel->getPemberitahuan(session('id')),
            'menu' => $accessModel->getAccessMenu(session('role_id')),
            'lomba' => $teamModel->teamLomba(session('id'))
        ];


        return view('dashboard/main', $data);
    }

    public function manageUser()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $userModel = new UserModel();
        $user_list = $userModel->getUser();
        $accessModel = new AccessModel();

        $data = [
            'tes' => 'admin',
            'menu' => $accessModel->getAccessMenu(session('role_id'))
        ];

        return view('dashboard/menu/manage_user', $data);
    }

    public function getAllUser()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $userModel = new UserModel();
        $user_list = $userModel->getUser();

        return $this->respond(json_encode($user_list));
    }

    public function update()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $data = [
            'id' => $this->request->getPost('id'),
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'asal_kampus' => $this->request->getPost('asal_kampus'),
            'role_id' => $this->request->getPost('role_id'),
            'is_active' => $this->request->getPost('is_active'),
        ];

        $userModel = new UserModel();
        $result = $userModel->updateUser($data);

        return $this->respondCreated(json_encode($result));
    }

    public function delete()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $data = [
            'id' => $this->request->getPost('id'),
            'name' => $this->request->getPost('name'),
        ];

        $userModel = new UserModel();
        $result = $userModel->deleteUser($data);

        return $this->respondDeleted(json_encode($result));
    }


    public function manageTeam()
    {
        $accessModel = new AccessModel();
        $adminModel = new AdminModel();
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $id = '';
        $lomba = $this->request->getGet('lomba');
        switch ($lomba) {
            case 'mazebot':
                $id = 1;
                break;
            case 'transporter':
                $id = 2;
                break;
            case 'eec':
                $id = 3;
                break;
            case 'iot':
                $id = 4;
                break;
            case 'video':
                $id = 5;
                break;
            default:
                break;
        }


        $data = [
            'tes' => 'admin',
            'lomba' => $lomba,
            'lomba_id' => $id,
            'menu' => $accessModel->getAccessMenu(session('role_id'))
        ];

        return view('dashboard/menu/manage_team', $data);
    }

    public function getAllTeam()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $lomba_id = $this->request->getPost('lomba_id');

        $adminModel = new AdminModel();
        $team_list = $adminModel->getTeam($lomba_id);

        return $this->respond(json_encode($team_list));
    }

    public function getTeamMember()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }
        $team_id = $this->request->getPost('team_id');

        $adminModel = new AdminModel();
        $team_member = $adminModel->getTeamMember($team_id);

        return $this->respond(json_encode($team_member));
    }

    public function updateTeam()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $data = [
            'team_id' => $this->request->getPost('team_id'),
            'is_paid' => $this->request->getPost('is_paid'),
        ];

        $adminModel = new AdminModel();
        $result = $adminModel->updateTeam($data);

        return $this->respondCreated(json_encode($data));
    }

    public function daftarRobotik()
    {
        $teamModel = new TeamModel();
        $accessModel = new AccessModel();
        $data = [
            'css' => array(base_url('/frontend/akun/dashboard/events/Regist/css/form.css')),
            'menu' => $accessModel->getAccessMenu(session('role_id')),
            'validation' => \Config\Services::validation()
        ];
        // Cek apakah user telah membuat team
        if ($this->_isHaveTeam(session('id'))) {
            return redirect()->back();
        }

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'team_name' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Nama tim tidak boleh kosong'
                    ]
                ],
                'institusi' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Asal instansi tidak boleh kosong'
                    ]
                ],
                'name.*' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Nama anggota tim tidak boleh ada yang kosong'
                    ]
                ],
                'ktm.*' => [
                    'rules' => 'uploaded[ktm]|max_size[ktm,512]|is_image[ktm]',
                    'errors' => [
                        'uploaded' => 'Foto KTM tidak boleh ada yang kosong',
                        'max_size' => 'Ukuran file terlalu besar (max 512kb)',
                        'is_image' => 'Mohon masukkan format file yang valid'
                    ]
                ],
                'lomba' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Cabang lomba tidak boleh kosong'
                    ]
                ]
            ];
            // validasi input
            if (!$this->validate($rules)) {
                $validation =  \Config\Services::validation();
                $this->session->setFlashdata('errors', $validation->getErrors());
                return redirect()->back()->withInput();
            }
            $dataTeam = [
                'user_id' => session('id'),
                'lomba_id' =>  $this->request->getPost('lomba'),
                'team_name' => htmlspecialchars(trim($this->request->getPost('team_name'))),
                'institusi' => $this->request->getPost('institusi'),
                'image_payment' => '',
                'is_paid' => 0
            ];
            // insert data team
            $teamModel->createTeam($dataTeam);
            $team = $teamModel->getTeam(session('id'));

            $file = $this->request->getFiles();
            foreach ($file['ktm'] as $key => $f) {
                $image = $f->getClientName();
                $imageExtension = $f->guessExtension();
                $imageFileName = $team['id'] . '_' . $_POST['name'][$key] . '.' . $imageExtension;
                $f->move(ROOTPATH . 'public/uploads/team/member_team', $imageFileName);

                $member[] = array(
                    'team_id' => $team['id'],
                    'name' => htmlspecialchars(trim($_POST['name'][$key])),
                    'image' => '',
                    'ktm' => $imageFileName
                );
            }

            // insert data member team
            $teamModel->createMultipleMember($member);

            // kirim email

            $message = view('email/pembayaran');
            $this->_sendEmail(session('email'), 'Terima kasih telah mendaftar', $message);

            $this->session->setFlashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Pendaftaran berhasil. Segera lakukan pembayaran.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>');

            return redirect()->to(base_url('menu/dashboard'));
        }

        return view('dashboard/menu/daftar_robotik', $data);
    }

    public function daftar($namaLomba)
    {

        $lombaModel = new LombaModel();
        $teamModel = new TeamModel();
        $accessModel = new AccessModel();
        $data = [
            'menu' => $accessModel->getAccessMenu(session('role_id')),
            'css' => array(base_url('/frontend/akun/dashboard/events/regist/css/form.css')),
            'lomba' => $lombaModel->getLomba($namaLomba),
            'validation' => \Config\Services::validation()
        ];

        // cek apakah user telah membuat team
        if ($this->_isHaveTeam(session('id')) || empty(($data['lomba']))) {
            return redirect()->back();
        }
        if ($this->request->getMethod() == 'post') {

            $rules = [
                'team_name' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Nama tim tidak boleh kosong'
                    ]
                ],
                'institusi' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Asal instansi tidak boleh kosong'
                    ]
                ],
                'name.*' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Nama anggota tidak boleh ada yang kosong'
                    ]
                ],
                'ktm.*' => [
                    'rules' => 'uploaded[ktm]|max_size[ktm,512]|is_image[ktm]',
                    'errors' => [
                        'uploaded' => 'Foto KTM tidak boleh ada yang kosong',
                        'max_size' => 'Ukuran file terlalu besar (max 512kb)',
                        'is_image' => 'Mohon masukkan format file yang valid'
                    ]
                ]

            ];
            // validasi input
            if (!$this->validate($rules)) {

                $validation =  \Config\Services::validation();

                $this->session->setFlashdata('errors', $validation->getErrors());
                return redirect()->back()->withInput();
            }

            $dataTeam = [
                'user_id' => session('id'),
                'lomba_id' => $data['lomba']['id'],
                'team_name' => htmlspecialchars(trim($this->request->getPost('team_name'))),
                'institusi' => htmlspecialchars(trim($this->request->getPost('institusi'))),
                'image_payment' => '',
                'is_paid' => 0
            ];
            $teamModel->createTeam($dataTeam);
            $team = $teamModel->getTeam(session('id'));

            $file = $this->request->getFiles();
            foreach ($file['ktm'] as $key => $f) {
                $image = $f->getClientName();
                $imageExtension = $f->guessExtension();
                $imageFileName = $team['id'] . '_' . $_POST['name'][$key] . '.' . $imageExtension;
                $f->move(ROOTPATH . 'public/uploads/team/member_team', $imageFileName);

                $member[] = array(
                    'team_id' => $team['id'],
                    'name' => htmlspecialchars(trim($_POST['name'][$key])),
                    'image' => '',
                    'ktm' => $imageFileName
                );
            }


            // input member team
            $teamModel->createMultipleMember($member);
            // kirim email
            $message = view('email/pembayaran');
            $this->_sendEmail(session('email'), 'Terima kasih telah mendaftar', $message);

            $this->session->setFlashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Pendaftaran berhasil. Segera lakukan pembayaran.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>');

            return redirect()->to(base_url('/menu/dashboard'));
        }
        return view('dashboard/menu/daftar_eec', $data);
    }
    public function daftarIot()
    {

        $lombaModel = new LombaModel();
        $teamModel = new TeamModel();
        $adminModel = new AdminModel();
        $accessModel = new AccessModel();
        $data = [
            'menu' => $accessModel->getAccessMenu(session('role_id')),
            'css' => array(base_url('/frontend/akun/dashboard/events/Regist/css/form.css')),
            'lomba' => $lombaModel->getLomba('iot'),
            'validation' => \Config\Services::validation()
        ];

        // cek apakah user telah membuat team
        if ($this->_isHaveTeam(session('id'))) {
            return redirect()->back();
        }
        if ($this->request->getMethod() == 'post') {
            $rules = [
                'team_name' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Nama tim tidak boleh kosong'
                    ]
                ],
                'institusi' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Asal instansi tidak boleh kosong'
                    ]
                ],
                'name.*' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Nama anggota tidak boleh ada yang kosong'
                    ]
                ],
                'ktm.*' => [
                    'rules' => 'uploaded[ktm]|max_size[ktm,512]|is_image[ktm]',
                    'errors' => [
                        'uploaded' => 'Foto KTM tidak boleh ada yang kosong',
                        'max_size' => 'Ukuran file terlalu besar (max 512kb)',
                        'is_image' => 'Mohon masukkan gambar'
                    ]
                ],
                'twibbon.*' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Link twibbon tidak boleh ada yang kosong'
                    ]
                ]
            ];
            // validasi input
            if (!$this->validate($rules)) {

                $validation =  \Config\Services::validation();
                $this->session->setFlashdata('errors', $validation->getErrors());
                return redirect()->back()->withInput();
            }


            $file = $this->request->getFiles();

            foreach ($file['ktm'] as $f) {
                $f->move(ROOTPATH . 'public/uploads/team/member_team');
            }

            $dataTeam = [
                'user_id' => session('id'),
                'lomba_id' => $data['lomba']['id'],
                'team_name' => htmlspecialchars(trim($this->request->getPost('team_name'))),
                'institusi' => htmlspecialchars(trim($this->request->getPost('institusi'))),
                'image_payment' => '',
                'is_paid' => 0
            ];
            $teamModel->createTeam($dataTeam);
            $team = $teamModel->getTeam(session('id'));

            foreach ($this->request->getPost('name') as $key => $val) {
                $member[] = array(
                    'team_id' => $team['id'],
                    'name' => htmlspecialchars(trim($_POST['name'][$key])),
                    'image' => trim($_POST['twibbon'][$key]),
                    'ktm' => $file['ktm'][$key]->getClientName()
                );
            }
            // input member team
            $teamModel->createMultipleMember($member);

            // Make announcement
            $data_pemberitahuan = [
                'judul' => 'Segera Kirim Proposal',
                'isi' => 'Harap bagi peserta IOT competition untuk mengirim proposal ke technocorner2021@gmail.com',
                'type' => 1,
                'identity' => array(session('id'))
            ];
            $adminModel->addPemberitahuan($data_pemberitahuan);
            // kirim email
            $message = view('email/pembayaran');
            $message2 = view('email/proposal');
            $this->_sendEmail(session('email'), 'Terima kasih telah mendaftar', $message);
            $this->_sendEmail(session('email'), 'Terima kasih telah mendaftar', $message2);

            $this->session->setFlashdata('message', '<div class="alert alert-success alert-dismissible fade show" role="alert">
                Pendaftaran berhasil. Segera lakukan pembayaran.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>');

            return redirect()->to(base_url('/menu/dashboard'));
        }
        return view('dashboard/menu/daftar_iot', $data);
    }
    private function _isHaveTeam($userId)
    {
        $teamModel = new TeamModel();
        return $teamModel->getTeam($userId);
    }

    private function _sendEmail($to, $subject, $message)
    {
        $email = \Config\Services::email();

        $email->setFrom('softwebtc21@gmail.com', 'technocorner2021');
        $email->setTo($to);
        $email->setSubject($subject);
        $email->setMessage($message);

        if (!$email->send()) {
            return false;
        } else {
            return true;
        }
    }


    public function managePemberitahuan()
    {
        $accessModel = new AccessModel();
        if (session('role_id') != 1) {
            return redirect()->back();
        }
        $data = [
            'menu' => $accessModel->getAccessMenu(session('role_id'))
        ];

        return view('dashboard/menu/manage_pemberitahuan', $data);
    }

    public function getUserAutocomplete()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $term = $this->request->getPost('term');

        $adminModel = new adminModel();
        $user_list = $adminModel->getUser($term);

        echo json_encode($user_list);
    }

    public function addPemberitahuan()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }


        $data = [
            'type' => $this->request->getPost('type'),
            'judul' => $this->request->getPost('judul'),
            'isi' => $this->request->getPost('isi'),
            'identity' => $this->request->getPost('identity')
        ];


        $adminModel = new adminModel();
        $result = $adminModel->addPemberitahuan($data);

        return $this->respondCreated(json_encode($result));
    }

    public function getListPemberitahuan()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $adminModel = new adminModel();
        $result = $adminModel->getListPemberitahuan();

        return $this->respondCreated(json_encode($result));
    }

    public function deletePemberitahuan()
    {
        if (session('role_id') != 1) {
            return redirect()->back();
        }

        $id = $this->request->getPost('id');

        $adminModel = new adminModel();
        $result = $adminModel->deletePemberitahuan($id);

        return $this->respondCreated(json_encode($result));
    }

    public function competition($lomba)
    {
        $accessModel = new AccessModel();
        $lombaModel = new LombaModel();
        $lomba = $lombaModel->getLomba($lomba);

        $data = [
            'lomba' => $lomba,
            'menu' => $accessModel->getAccessMenu(session('role_id')),
            'have_team' => $this->_isHaveTeam(session('id')),
            'agenda' => $lombaModel->getAgenda($lomba['id']),
            'kontak' => $lombaModel->getKontak($lomba['id']),
            'kategori' => $lombaModel->getKategori($lomba['id'])
        ];
        return view('dashboard/menu/lomba', $data);
    }

    public function event($event)
    {
        $accessModel = new AccessModel();
        $data = [
            'menu' => $accessModel->getAccessMenu(session('role_id'))
        ];
        if ($event == 'workshop') {
            return view('dashboard/menu/workshop', $data);
        } else if ($event == 'webinar') {
            return view('dashboard/menu/webinar', $data);
        }
    }
    public function profilteam()
    {
        $teamModel = new TeamModel();
        $data = [
            'team' => $teamModel->getTeam(session('id')),
            'member_team' => $teamModel->getMemberTeam(session('id'))
        ];

        return view('dashboard/menu/profile_team', $data);
    }

    public function profile()
    {
        $accessModel = new AccessModel();
        $userModel = new UserModel();

        if ($this->request->getMethod() == 'post') {
            $user = $userModel->getUser(session('email'));
            $rules = [
                'image' => [
                    'rules' => 'max_size[image,512]|is_image[image]',
                    'errors' => [
                        'max_size' => 'Ukuran file terlalu besar',
                        'is_image' => 'File yang di upload harus berupa gambar'
                    ]
                ]
            ];

            $file = $this->request->getFile('image');
            if (!empty($file->getClientName())) {
                if (!$this->validate($rules)) {
                    $validation =  \Config\Services::validation();
                    $this->session->setFlashdata('errors', $validation->getErrors());
                    return redirect()->back();
                }

                $file->move(ROOTPATH . 'public/uploads/user');
            }

            $data = [
                'name' => htmlspecialchars(trim($this->request->getPost('name'))),
                'asal_kampus' => htmlspecialchars(trim($this->request->getPost('asal_kampus'))),
                'image' => ($file->getClientName()) ? $file->getClientName() : $user['image']
            ];

            $userModel->updateProfile($data);
            $this->session->set($data);
        }

        $data = [
            'user' => $userModel->getUser(session('email')),
            'menu' => $accessModel->getAccessMenu(session('role_id')),
            'validation' => \Config\Services::validation()
        ];

        return view('dashboard/menu/profile', $data);
    }

    public function updateProfile()
    {
        $userModel = new UserModel();
        $user = $userModel->getUser(session('email'));
        $validatedFile = $this->validate([
            'image' => 'uploaded[image]|max_size[image,50]'
        ]);

        $file = $this->request->getFile('image');

        if ($validatedFile) {
            $file->move(ROOTPATH . 'public/uploads/user');
        }
        $data = [
            'name' => htmlspecialchars(trim($this->request->getPost('name'))),
            'asal_kampus' => htmlspecialchars(trim($this->request->getPost('asal_kampus'))),
            'image' => ($file->getClientName()) ? $file->getClientName() : $user['image']
        ];

        $userModel = new UserModel();
        $userModel->updateProfile($data);
        $this->session->set($data);
        $validation = \Config\Services::validation();

        return redirect()->back()->with('validation', $validation);
    }
}
